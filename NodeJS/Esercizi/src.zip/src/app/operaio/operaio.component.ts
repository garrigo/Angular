import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-operaio',
  templateUrl: './operaio.component.html',
  styleUrls: ['./operaio.component.css']
})
export class OperaioComponent {
  
  prelievo : number = 0;
  @Output() evento = new EventEmitter<number>;
  invia() : void {
    this.evento.emit(this.prelievo >= 0 && this.prelievo <= 500 ? this.prelievo : 0);
  }
}
