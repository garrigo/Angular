import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperaioComponent } from './operaio.component';

describe('OperaioComponent', () => {
  let component: OperaioComponent;
  let fixture: ComponentFixture<OperaioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OperaioComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OperaioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
