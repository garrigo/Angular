import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { OperaioComponent } from './operaio/operaio.component';
import { DirigenteComponent } from './dirigente/dirigente.component';
import { CeoComponent } from './ceo/ceo.component';

@NgModule({
  declarations: [
    AppComponent,
    OperaioComponent,
    DirigenteComponent,
    CeoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
