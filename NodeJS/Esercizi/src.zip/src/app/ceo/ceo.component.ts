import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-ceo',
  templateUrl: './ceo.component.html',
  styleUrls: ['./ceo.component.css']
})
export class CeoComponent {
  prelievo : number = 0;
  deposito : number = 0;
  @Output() evento = new EventEmitter<number>;
  preleva() : void {
    this.evento.emit(this.prelievo >= 0 ? this.prelievo : 0);
  }
  deposita() : void {
    this.evento.emit(this.deposito >= 0 ? this.deposito * (-1) : 0);
  }
}
