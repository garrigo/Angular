import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-dirigente',
  templateUrl: './dirigente.component.html',
  styleUrls: ['./dirigente.component.css']
})
export class DirigenteComponent {
  prelievo : number = 0;
  @Output() evento = new EventEmitter<number>;
  invia() : void {
    this.evento.emit(this.prelievo >= 0 && this.prelievo <= 5000 ? this.prelievo : 0);
  }
}
