import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DirigenteComponent } from './dirigente.component';

describe('DirigenteComponent', () => {
  let component: DirigenteComponent;
  let fixture: ComponentFixture<DirigenteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DirigenteComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DirigenteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
